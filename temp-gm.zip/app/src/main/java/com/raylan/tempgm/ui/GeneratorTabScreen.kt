package com.raylan.tempgm.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.tempgm.MailServer
import com.raylan.tempgm.R
import com.raylan.tempgm.TempGmUiState
import com.raylan.tempgm.ValidityOption
import com.raylan.tempgm.ui.theme.CyberBackground
import com.raylan.tempgm.ui.theme.CyberBorder
import com.raylan.tempgm.ui.theme.CyberDanger
import com.raylan.tempgm.ui.theme.CyberSurface
import com.raylan.tempgm.ui.theme.CyberSurfaceElevated
import com.raylan.tempgm.ui.theme.CyberTextPrimary
import com.raylan.tempgm.ui.theme.CyberTextSecondary
import com.raylan.tempgm.ui.theme.ElectricBlue
import com.raylan.tempgm.ui.theme.EmeraldGreen

@Composable
fun GeneratorTabScreen(
    uiState: TempGmUiState,
    onCopyEmail: (String) -> Unit,
    onSelectValidity: (Int) -> Unit,
    onSetGenerationMode: (Boolean) -> Unit,
    onCustomPrefixChange: (String) -> Unit,
    onRegenerateAiPreview: () -> Unit,
    onSelectServer: (MailServer) -> Unit,
    onGenerateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. E-MAIL ATIVO EM DESTAQUE
            ActiveEmailSpotlightCard(
                uiState = uiState,
                onCopy = { address ->
                    runCatching {
                        clipboardManager.setText(AnnotatedString(address))
                    }
                    onCopyEmail(address)
                }
            )

            // 2. VALIDADE DA CONTA (5, 10, 15, 20 DIAS) + PROGRESSO
            ValiditySelectorCard(
                selectedDays = uiState.selectedValidityDays,
                hasActiveAccount = uiState.activeAccount != null,
                remainingTimeText = uiState.remainingTimeText,
                remainingProgress = uiState.remainingProgress,
                isExpired = uiState.isExpired,
                onSelectValidity = onSelectValidity
            )

            // 3. MODO DE GERAÇÃO: IA REALISTA OU PREFIXO PERSONALIZADO
            PrefixModeCard(
                useCustomPrefix = uiState.useCustomPrefix,
                customPrefixInput = uiState.customPrefixInput,
                aiPreviewUsername = uiState.aiPreviewUsername,
                onSetMode = onSetGenerationMode,
                onCustomPrefixChange = onCustomPrefixChange,
                onRegeneratePreview = onRegenerateAiPreview
            )

            // 4. SELETOR MANUAL DE SERVIDOR
            ServerSelectorCard(
                selectedServer = uiState.selectedServer,
                activeAccountServer = uiState.activeAccount?.server,
                onSelectServer = onSelectServer
            )

            // 5. BOTÃO PRINCIPAL GERAR NOVO E-MAIL
            Button(
                onClick = onGenerateClick,
                enabled = !uiState.isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("generate_email_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBlue,
                    contentColor = Color.White,
                    disabledContainerColor = ElectricBlue.copy(alpha = 0.45f)
                )
            ) {
                if (uiState.isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "CONECTANDO AO SERVIDOR...",
                        style = MaterialTheme.typography.labelLarge
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Gerar novo e-mail",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.btn_generate_email),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            // Rodapé oficial
            OfficialFooter()
        }
    }
}

@Composable
private fun ActiveEmailSpotlightCard(
    uiState: TempGmUiState,
    onCopy: (String) -> Unit
) {
    val account = uiState.activeAccount
    val borderBrush = Brush.linearGradient(
        colors = if (account != null && !uiState.isExpired) {
            listOf(ElectricBlue, EmeraldGreen)
        } else {
            listOf(CyberBorder, CyberBorder)
        }
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.5.dp, borderBrush)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = when {
                                    account == null -> CyberTextSecondary
                                    uiState.isExpired -> CyberDanger
                                    else -> EmeraldGreen
                                },
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when {
                            account == null -> "AGUARDANDO GERAÇÃO"
                            uiState.isExpired -> "CONTA EXPIRADA"
                            else -> "CAIXA ATIVA • PERSISTENTE"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            account == null -> CyberTextSecondary
                            uiState.isExpired -> CyberDanger
                            else -> EmeraldGreen
                        }
                    )
                }

                if (account != null) {
                    Surface(
                        color = ElectricBlue.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = if (account.server == MailServer.MAIL_TM) "SRV 1" else "SRV 2",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ElectricBlue,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (account != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberBackground,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AlternateEmail,
                            contentDescription = "Endereço de e-mail",
                            tint = ElectricBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = account.address,
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { onCopy(account.address) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("copy_email_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldGreen,
                        contentColor = Color(0xFF042111)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCopy,
                        contentDescription = "Copiar endereço",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_copy_email),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            } else {
                Text(
                    text = "Nenhum e-mail gerado ainda",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Escolha a validade, configure o prefixo ou deixe no Gerador IA Realista e toque em GERAR NOVO E-MAIL abaixo.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary
                )
            }
        }
    }
}

@Composable
private fun ValiditySelectorCard(
    selectedDays: Int,
    hasActiveAccount: Boolean,
    remainingTimeText: String,
    remainingProgress: Float,
    isExpired: Boolean,
    onSelectValidity: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = "Validade da conta",
                        tint = ElectricBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Validade da Conta",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary
                    )
                }
                Text(
                    text = "$selectedDays DIAS",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = FontFamily.Monospace,
                    color = EmeraldGreen
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ValidityOption.entries.forEach { option ->
                    val isSelected = option.days == selectedDays
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectValidity(option.days) }
                            .testTag("validity_${option.days}_days"),
                        color = if (isSelected) ElectricBlue.copy(alpha = 0.2f) else CyberSurfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) ElectricBlue else CyberBorder
                        )
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = option.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) CyberTextPrimary else CyberTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LinearProgressIndicator(
                progress = { if (hasActiveAccount) remainingProgress else 1f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(99.dp)),
                color = when {
                    !hasActiveAccount -> CyberBorder
                    isExpired -> CyberDanger
                    remainingProgress < 0.2f -> CyberDanger
                    else -> EmeraldGreen
                },
                trackColor = CyberBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (hasActiveAccount) remainingTimeText else "Prazo definido: $selectedDays dias após geração",
                style = MaterialTheme.typography.labelMedium,
                fontFamily = FontFamily.Monospace,
                color = if (isExpired) CyberDanger else CyberTextSecondary
            )
        }
    }
}

@Composable
private fun PrefixModeCard(
    useCustomPrefix: Boolean,
    customPrefixInput: String,
    aiPreviewUsername: String,
    onSetMode: (Boolean) -> Unit,
    onCustomPrefixChange: (String) -> Unit,
    onRegeneratePreview: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Modo de Identidade",
                style = MaterialTheme.typography.titleMedium,
                color = CyberTextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ModeChip(
                    title = "Gerador IA Realista",
                    icon = Icons.Filled.AutoAwesome,
                    selected = !useCustomPrefix,
                    onClick = { onSetMode(false) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_ai_realistic")
                )
                ModeChip(
                    title = "Prefixo Personalizado",
                    icon = Icons.Filled.Edit,
                    selected = useCustomPrefix,
                    onClick = { onSetMode(true) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_custom_prefix")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (useCustomPrefix) {
                OutlinedTextField(
                    value = customPrefixInput,
                    onValueChange = onCustomPrefixChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_prefix_input"),
                    singleLine = true,
                    label = { Text("Prefixo desejado (ex: raylan.vip)") },
                    placeholder = {
                        Text(
                            "raylan.vip",
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        color = CyberTextPrimary
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = CyberBorder,
                        focusedLabelColor = ElectricBlue,
                        unfocusedLabelColor = CyberTextSecondary,
                        cursorColor = EmeraldGreen
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Exemplo gerado pela IA:",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextSecondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$aiPreviewUsername@...",
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                color = EmeraldGreen
                            )
                        }
                        IconButton(
                            onClick = onRegeneratePreview,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Sortear outro exemplo de nome",
                                tint = ElectricBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        color = if (selected) ElectricBlue.copy(alpha = 0.2f) else CyberSurfaceElevated,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) ElectricBlue else CyberBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (selected) ElectricBlue else CyberTextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) CyberTextPrimary else CyberTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ServerSelectorCard(
    selectedServer: MailServer,
    activeAccountServer: MailServer?,
    onSelectServer: (MailServer) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Dns,
                    contentDescription = "Seletor de servidor",
                    tint = ElectricBlue,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Servidor Manual",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Troca apenas quando você clicar. Seu e-mail ativo nunca muda sozinho.",
                style = MaterialTheme.typography.bodyMedium,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MailServer.entries.forEach { server ->
                    val isSelected = server == selectedServer
                    val isCurrentActive = server == activeAccountServer
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectServer(server) }
                            .testTag("server_${server.id}"),
                        color = if (isSelected) ElectricBlue.copy(alpha = 0.14f) else CyberSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) ElectricBlue else CyberBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = server.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = CyberTextPrimary
                                    )
                                    if (isCurrentActive) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "EM USO",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = FontFamily.Monospace,
                                            color = EmeraldGreen
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = server.subtitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberTextSecondary
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Selecionado",
                                    tint = EmeraldGreen,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OfficialFooter() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = stringResource(R.string.official_credits),
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            color = CyberTextSecondary
        )
    }
}
