package com.raylan.tempgm

enum class MailServer(
    val id: String,
    val displayName: String,
    val subtitle: String,
    val badge: String
) {
    MAIL_TM(
        id = "mail_tm",
        displayName = "Servidor 1 • Alta Duração",
        subtitle = "Mail.tm • Sessão Bearer persistente (5–20 dias)",
        badge = "RECOMENDADO"
    ),
    ONE_SEC_MAIL(
        id = "1secmail",
        displayName = "Servidor 2 • Rápido",
        subtitle = "1secmail • Entrega instantânea sem registro",
        badge = "RÁPIDO"
    );

    companion object {
        fun fromId(id: String?): MailServer =
            entries.firstOrNull { it.id == id } ?: MAIL_TM
    }
}

enum class ValidityOption(val days: Int, val label: String) {
    FIVE(5, "5 dias"),
    TEN(10, "10 dias"),
    FIFTEEN(15, "15 dias"),
    TWENTY(20, "20 dias");

    companion object {
        fun fromDays(days: Int): ValidityOption =
            entries.firstOrNull { it.days == days } ?: TEN
    }
}

data class SavedAccount(
    val address: String,
    val password: String,
    val token: String,
    val accountId: String,
    val server: MailServer,
    val createdAtMillis: Long,
    val validityDays: Int,
    val expiresAtMillis: Long
)

data class EmailMessage(
    val id: String,
    val fromAddress: String,
    val fromName: String,
    val subject: String,
    val intro: String,
    val textBody: String,
    val htmlBody: String,
    val receivedAtIso: String,
    val receivedAtMillis: Long,
    val isRead: Boolean
)

data class AiExtractionResult(
    val verificationCode: String?,
    val confirmationLink: String?,
    val summary: String,
    val categoryLabel: String
)

data class InboxItemUi(
    val message: EmailMessage,
    val extraction: AiExtractionResult,
    val cleanBody: String
)
