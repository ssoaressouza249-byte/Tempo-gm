package com.raylan.tempgm

import android.content.Context
import android.content.Intent
import android.net.Uri

sealed class SecurityStatus {
    data object Valid : SecurityStatus()
    data class Tampered(val technicalReason: String) : SecurityStatus()
}

object SecurityGuard {

    private const val EXPECTED_APP_NAME = "Temp GM"
    private const val EXPECTED_PACKAGE_NAME = "com.raylan.tempgm"

    private val expectedCoreClasses = listOf(
        "SecurityGuard" to "com.raylan.tempgm.SecurityGuard",
        "MailRepository" to "com.raylan.tempgm.MailRepository",
        "AiCodeExtractor" to "com.raylan.tempgm.AiCodeExtractor"
    )

    fun verifyIntegrity(context: Context): SecurityStatus {
        return runCatching {
            val actualPackage = context.packageName
            if (actualPackage != EXPECTED_PACKAGE_NAME) {
                return@runCatching SecurityStatus.Tampered(
                    "PACKAGE_MISMATCH: esperado '$EXPECTED_PACKAGE_NAME', encontrado '$actualPackage'"
                )
            }

            val pm = context.packageManager
            val appInfo = context.applicationInfo
            val actualLabel = appInfo.loadLabel(pm)?.toString()?.trim().orEmpty()
            if (actualLabel != EXPECTED_APP_NAME) {
                return@runCatching SecurityStatus.Tampered(
                    "APP_LABEL_MODIFIED: esperado '$EXPECTED_APP_NAME', encontrado '$actualLabel'"
                )
            }

            val pkgInfo = pm.getPackageInfo(actualPackage, 0)
            if (pkgInfo.packageName != EXPECTED_PACKAGE_NAME) {
                return@runCatching SecurityStatus.Tampered(
                    "PACKAGE_INFO_MISMATCH: '${pkgInfo.packageName}'"
                )
            }

            // Verifica integridade dos nomes das classes principais (proteção contra MT Manager / NP Manager)
            // Sem bloquear certificados de debug do GitHub Actions ou builds locais.
            if (SecurityGuard::class.java.simpleName != "SecurityGuard" ||
                SecurityGuard::class.java.name != "com.raylan.tempgm.SecurityGuard"
            ) {
                return@runCatching SecurityStatus.Tampered(
                    "CLASS_TAMPERED: SecurityGuard -> ${SecurityGuard::class.java.name}"
                )
            }

            if (MailRepository::class.java.simpleName != "MailRepository" ||
                MailRepository::class.java.name != "com.raylan.tempgm.MailRepository"
            ) {
                return@runCatching SecurityStatus.Tampered(
                    "CLASS_TAMPERED: MailRepository -> ${MailRepository::class.java.name}"
                )
            }

            if (AiCodeExtractor::class.java.simpleName != "AiCodeExtractor" ||
                AiCodeExtractor::class.java.name != "com.raylan.tempgm.AiCodeExtractor"
            ) {
                return@runCatching SecurityStatus.Tampered(
                    "CLASS_TAMPERED: AiCodeExtractor -> ${AiCodeExtractor::class.java.name}"
                )
            }

            for ((simpleName, fullName) in expectedCoreClasses) {
                val clazz = Class.forName(fullName)
                if (clazz.simpleName != simpleName || clazz.name != fullName) {
                    return@runCatching SecurityStatus.Tampered(
                        "REFLECTION_MISMATCH: esperado '$fullName', encontrado '${clazz.name}'"
                    )
                }
            }

            SecurityStatus.Valid
        }.getOrElse { error ->
            SecurityStatus.Tampered(
                "INTEGRITY_EXCEPTION: ${error::class.java.simpleName} - ${error.message ?: "falha na verificação"}"
            )
        }
    }

    fun triggerUninstall(context: Context): Result<Unit> {
        return runCatching {
            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
