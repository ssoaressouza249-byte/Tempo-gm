package com.raylan.tempgm

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

class MailRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val random = SecureRandom()

    fun loadSavedAccount(): SavedAccount? {
        return runCatching {
            val raw = prefs.getString(KEY_ACCOUNT_JSON, null) ?: return@runCatching null
            val obj = JSONObject(raw)
            val address = obj.optString("address", "")
            if (address.isBlank()) return@runCatching null

            val createdAt = obj.optLong("createdAtMillis", System.currentTimeMillis())
            val validityDays = obj.optInt("validityDays", 10).coerceIn(5, 20)
            val expiresAt = obj.optLong(
                "expiresAtMillis",
                createdAt + validityDays * MILLIS_PER_DAY
            )

            SavedAccount(
                address = address,
                password = obj.optString("password", ""),
                token = obj.optString("token", ""),
                accountId = obj.optString("accountId", ""),
                server = MailServer.fromId(obj.optString("serverId")),
                createdAtMillis = createdAt,
                validityDays = validityDays,
                expiresAtMillis = expiresAt
            )
        }.getOrNull()
    }

    fun saveAccount(account: SavedAccount) {
        runCatching {
            val obj = JSONObject().apply {
                put("address", account.address)
                put("password", account.password)
                put("token", account.token)
                put("accountId", account.accountId)
                put("serverId", account.server.id)
                put("createdAtMillis", account.createdAtMillis)
                put("validityDays", account.validityDays)
                put("expiresAtMillis", account.expiresAtMillis)
            }
            prefs.edit()
                .putString(KEY_ACCOUNT_JSON, obj.toString())
                .putString(KEY_SELECTED_SERVER, account.server.id)
                .putInt(KEY_VALIDITY_DAYS, account.validityDays)
                .apply()
        }
    }

    fun updateActiveAccountValidity(days: Int): SavedAccount? {
        val current = loadSavedAccount() ?: run {
            savePreferredValidityDays(days)
            return null
        }
        val clamped = days.coerceIn(5, 20)
        val updated = current.copy(
            validityDays = clamped,
            expiresAtMillis = current.createdAtMillis + clamped * MILLIS_PER_DAY
        )
        saveAccount(updated)
        return updated
    }

    fun loadPreferredValidityDays(): Int {
        return runCatching {
            prefs.getInt(KEY_VALIDITY_DAYS, 10).coerceIn(5, 20)
        }.getOrDefault(10)
    }

    fun savePreferredValidityDays(days: Int) {
        runCatching {
            prefs.edit().putInt(KEY_VALIDITY_DAYS, days.coerceIn(5, 20)).apply()
        }
    }

    fun loadSelectedServer(): MailServer {
        return runCatching {
            val savedId = prefs.getString(KEY_SELECTED_SERVER, null)
            if (savedId != null) {
                MailServer.fromId(savedId)
            } else {
                loadSavedAccount()?.server ?: MailServer.MAIL_TM
            }
        }.getOrDefault(MailServer.MAIL_TM)
    }

    fun saveSelectedServer(server: MailServer) {
        runCatching {
            prefs.edit().putString(KEY_SELECTED_SERVER, server.id).apply()
        }
    }

    fun loadAutoRefreshEnabled(): Boolean {
        return runCatching {
            prefs.getBoolean(KEY_AUTO_REFRESH, true)
        }.getOrDefault(true)
    }

    fun saveAutoRefreshEnabled(enabled: Boolean) {
        runCatching {
            prefs.edit().putBoolean(KEY_AUTO_REFRESH, enabled).apply()
        }
    }

    fun loadSavedMessages(): List<EmailMessage> {
        return runCatching {
            val raw = prefs.getString(KEY_MESSAGES_JSON, null) ?: return@runCatching emptyList()
            val array = JSONArray(raw)
            val list = ArrayList<EmailMessage>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                list.add(
                    EmailMessage(
                        id = obj.optString("id"),
                        fromAddress = obj.optString("fromAddress"),
                        fromName = obj.optString("fromName"),
                        subject = obj.optString("subject", "(Sem assunto)"),
                        intro = obj.optString("intro"),
                        textBody = obj.optString("textBody"),
                        htmlBody = obj.optString("htmlBody"),
                        receivedAtIso = obj.optString("receivedAtIso"),
                        receivedAtMillis = obj.optLong("receivedAtMillis", 0L),
                        isRead = obj.optBoolean("isRead", false)
                    )
                )
            }
            list.sortedByDescending { it.receivedAtMillis }
        }.getOrDefault(emptyList())
    }

    fun saveMessages(messages: List<EmailMessage>) {
        runCatching {
            val array = JSONArray()
            messages.sortedByDescending { it.receivedAtMillis }.forEach { msg ->
                val obj = JSONObject().apply {
                    put("id", msg.id)
                    put("fromAddress", msg.fromAddress)
                    put("fromName", msg.fromName)
                    put("subject", msg.subject)
                    put("intro", msg.intro)
                    put("textBody", msg.textBody)
                    put("htmlBody", msg.htmlBody)
                    put("receivedAtIso", msg.receivedAtIso)
                    put("receivedAtMillis", msg.receivedAtMillis)
                    put("isRead", msg.isRead)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_MESSAGES_JSON, array.toString()).apply()
        }
    }

    fun markMessageAsRead(messageId: String): List<EmailMessage> {
        val updated = loadSavedMessages().map { msg ->
            if (msg.id == messageId) msg.copy(isRead = true) else msg
        }
        saveMessages(updated)
        return updated
    }

    suspend fun generateNewEmail(
        server: MailServer,
        customPrefix: String?,
        validityDays: Int
    ): Result<SavedAccount> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanPrefix = customPrefix
                ?.let { AiCodeExtractor.sanitizeCustomPrefix(it) }
                ?.takeIf { it.isNotBlank() }

            val account = when (server) {
                MailServer.MAIL_TM -> createMailTmAccount(cleanPrefix, validityDays)
                MailServer.ONE_SEC_MAIL -> createOneSecMailAccount(cleanPrefix, validityDays)
            }

            // Apenas ao confirmar explicitamente a geração de um novo e-mail substituímos o histórico anterior
            saveAccount(account)
            saveMessages(emptyList())
            account
        }
    }

    suspend fun refreshMessages(account: SavedAccount): Result<List<EmailMessage>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val existingList = loadSavedMessages()
                val existingById = existingList.associateBy { it.id }.toMutableMap()

                val fetched = when (account.server) {
                    MailServer.MAIL_TM -> fetchMailTmMessages(account, existingById)
                    MailServer.ONE_SEC_MAIL -> fetchOneSecMailMessages(account, existingById)
                }

                // Mescla preservando todas as mensagens antigas salvas localmente
                fetched.forEach { msg ->
                    val prev = existingById[msg.id]
                    existingById[msg.id] = if (prev != null) {
                        msg.copy(isRead = prev.isRead || msg.isRead)
                    } else {
                        msg
                    }
                }

                val merged = existingById.values.sortedByDescending { it.receivedAtMillis }
                saveMessages(merged)
                merged
            }
        }

    // ==================== SERVIDOR 1: MAIL.TM ====================

    private fun createMailTmAccount(customPrefix: String?, validityDays: Int): SavedAccount {
        val domain = fetchMailTmDomain()
        val isCustom = !customPrefix.isNullOrBlank()
        var username = customPrefix ?: AiCodeExtractor.generateRealisticUsername()
        val password = generateSecurePassword()

        var address = "$username@$domain"
        var createResult = postMailTmAccount(address, password)

        if (!createResult.first && createResult.second == 422 && !isCustom) {
            username = "${username}${10 + random.nextInt(89)}"
            address = "$username@$domain"
            createResult = postMailTmAccount(address, password)
        }

        if (!createResult.first) {
            val reason = when (createResult.second) {
                422 -> "Este endereço ($address) já está em uso. Tente outro prefixo."
                429 -> "Limite temporário de requisições no Servidor 1. Aguarde alguns segundos."
                else -> "Falha ao criar conta no Servidor 1 (HTTP ${createResult.second})."
            }
            error(reason)
        }

        val (token, accountId) = fetchMailTmToken(address, password)
        val now = System.currentTimeMillis()
        val days = validityDays.coerceIn(5, 20)

        return SavedAccount(
            address = address,
            password = password,
            token = token,
            accountId = accountId,
            server = MailServer.MAIL_TM,
            createdAtMillis = now,
            validityDays = days,
            expiresAtMillis = now + days * MILLIS_PER_DAY
        )
    }

    private fun fetchMailTmDomain(): String {
        val request = Request.Builder()
            .url("$MAIL_TM_BASE/domains")
            .get()
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("Não foi possível consultar domínios do Servidor 1 (HTTP ${response.code}).")
            }
            val body = response.body?.string().orEmpty()
            val json = JSONObject(body)
            val members = json.optJSONArray("hydra:member") ?: JSONArray()
            val activeDomains = mutableListOf<String>()
            for (i in 0 until members.length()) {
                val item = members.optJSONObject(i) ?: continue
                val domain = item.optString("domain")
                val isActive = item.optBoolean("isActive", true)
                val isPrivate = item.optBoolean("isPrivate", false)
                if (domain.isNotBlank() && isActive && !isPrivate) {
                    activeDomains.add(domain)
                }
            }
            if (activeDomains.isEmpty()) {
                error("Nenhum domínio ativo encontrado no Servidor 1.")
            }
            return activeDomains[random.nextInt(activeDomains.size)]
        }
    }

    private fun postMailTmAccount(address: String, password: String): Pair<Boolean, Int> {
        val payload = JSONObject().apply {
            put("address", address)
            put("password", password)
        }.toString()

        val request = Request.Builder()
            .url("$MAIL_TM_BASE/accounts")
            .post(payload.toRequestBody(jsonMediaType))
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            return response.isSuccessful to response.code
        }
    }

    private fun fetchMailTmToken(address: String, password: String): Pair<String, String> {
        val payload = JSONObject().apply {
            put("address", address)
            put("password", password)
        }.toString()

        val request = Request.Builder()
            .url("$MAIL_TM_BASE/token")
            .post(payload.toRequestBody(jsonMediaType))
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("Falha na autenticação Bearer do Servidor 1 (HTTP ${response.code}).")
            }
            val body = response.body?.string().orEmpty()
            val json = JSONObject(body)
            val token = json.optString("token")
            val id = json.optString("id")
            if (token.isBlank()) {
                error("Token de sessão vazio retornado pelo Servidor 1.")
            }
            return token to id
        }
    }

    private fun fetchMailTmMessages(
        account: SavedAccount,
        existingById: Map<String, EmailMessage>
    ): List<EmailMessage> {
        var activeToken = account.token
        var listResponse = executeMailTmMessagesRequest(activeToken)

        // Se o token JWT expirou após dias, renova silenciosamente na mesma conta e servidor
        if (listResponse.first == 401 && account.password.isNotBlank()) {
            val (newToken, _) = fetchMailTmToken(account.address, account.password)
            activeToken = newToken
            saveAccount(account.copy(token = newToken))
            listResponse = executeMailTmMessagesRequest(activeToken)
        }

        val (statusCode, bodyString) = listResponse
        if (statusCode !in 200..299) {
            error("Erro ao consultar caixa de entrada (HTTP $statusCode).")
        }

        val json = JSONObject(bodyString)
        val members = json.optJSONArray("hydra:member") ?: JSONArray()
        val result = ArrayList<EmailMessage>(members.length())

        for (i in 0 until members.length()) {
            val summaryObj = members.optJSONObject(i) ?: continue
            val id = summaryObj.optString("id")
            if (id.isBlank()) continue

            val cached = existingById[id]
            if (cached != null && (cached.textBody.isNotBlank() || cached.htmlBody.isNotBlank())) {
                result.add(cached)
                continue
            }

            val fullMsg = fetchMailTmMessageDetail(id, activeToken, summaryObj)
            result.add(fullMsg)
        }

        return result
    }

    private fun executeMailTmMessagesRequest(token: String): Pair<Int, String> {
        val request = Request.Builder()
            .url("$MAIL_TM_BASE/messages?page=1")
            .get()
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            return response.code to response.body?.string().orEmpty()
        }
    }

    private fun fetchMailTmMessageDetail(
        id: String,
        token: String,
        summaryObj: JSONObject
    ): EmailMessage {
        val request = Request.Builder()
            .url("$MAIL_TM_BASE/messages/$id")
            .get()
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()

        val detailJson = runCatching {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    JSONObject(response.body?.string().orEmpty())
                } else {
                    summaryObj
                }
            }
        }.getOrElse { summaryObj }

        val fromObj = detailJson.optJSONObject("from") ?: summaryObj.optJSONObject("from")
        val fromAddress = fromObj?.optString("address").orEmpty()
        val fromName = fromObj?.optString("name").orEmpty()
        val subject = detailJson.optString("subject").ifBlank { "(Sem assunto)" }
        val intro = detailJson.optString("intro").ifBlank { summaryObj.optString("intro") }
        val textBody = detailJson.optString("text").ifBlank { intro }
        val htmlField = detailJson.opt("html")
        val htmlBody = when (htmlField) {
            is JSONArray -> buildString {
                for (j in 0 until htmlField.length()) {
                    append(htmlField.optString(j))
                }
            }
            is String -> htmlField
            else -> ""
        }

        val createdAtIso = detailJson.optString("createdAt")
            .ifBlank { summaryObj.optString("createdAt") }
        val timestampMillis = parseIsoTimestamp(createdAtIso)

        return EmailMessage(
            id = id,
            fromAddress = fromAddress,
            fromName = fromName,
            subject = subject,
            intro = intro,
            textBody = textBody,
            htmlBody = htmlBody,
            receivedAtIso = createdAtIso,
            receivedAtMillis = timestampMillis,
            isRead = detailJson.optBoolean("seen", false)
        )
    }

    // ==================== SERVIDOR 2: 1SECMAIL ====================

    private fun createOneSecMailAccount(customPrefix: String?, validityDays: Int): SavedAccount {
        val domains = fetchOneSecMailDomains()
        val domain = domains[random.nextInt(domains.size)]
        val username = customPrefix ?: AiCodeExtractor.generateRealisticUsername()
        val address = "$username@$domain"
        val now = System.currentTimeMillis()
        val days = validityDays.coerceIn(5, 20)

        return SavedAccount(
            address = address,
            password = "",
            token = "1secmail_active",
            accountId = username,
            server = MailServer.ONE_SEC_MAIL,
            createdAtMillis = now,
            validityDays = days,
            expiresAtMillis = now + days * MILLIS_PER_DAY
        )
    }

    private fun fetchOneSecMailDomains(): List<String> {
        val request = Request.Builder()
            .url("$ONE_SEC_MAIL_BASE/?action=getDomainList")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("Servidor 2 indisponível (HTTP ${response.code}).")
            }
            val raw = response.body?.string().orEmpty()
            val array = JSONArray(raw)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) {
                val d = array.optString(i)
                if (d.isNotBlank()) list.add(d)
            }
            if (list.isEmpty()) {
                error("Nenhum domínio ativo encontrado no Servidor 2.")
            }
            return list
        }
    }

    private fun fetchOneSecMailMessages(
        account: SavedAccount,
        existingById: Map<String, EmailMessage>
    ): List<EmailMessage> {
        val login = account.address.substringBefore("@")
        val domain = account.address.substringAfter("@")
        if (login.isBlank() || domain.isBlank()) {
            error("Endereço inválido para o Servidor 2.")
        }

        val listUrl = "$ONE_SEC_MAIL_BASE/?action=getMessages&login=$login&domain=$domain"
        val request = Request.Builder().url(listUrl).get().build()

        val rawList = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("Erro ao consultar Servidor 2 (HTTP ${response.code}).")
            }
            response.body?.string().orEmpty()
        }

        val array = JSONArray(rawList)
        val result = ArrayList<EmailMessage>(array.length())

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val msgId = item.opt("id")?.toString().orEmpty()
            if (msgId.isBlank()) continue

            val cached = existingById[msgId]
            if (cached != null && (cached.textBody.isNotBlank() || cached.htmlBody.isNotBlank())) {
                result.add(cached)
                continue
            }

            val detail = fetchOneSecMailMessageDetail(login, domain, msgId, item)
            result.add(detail)
        }

        return result
    }

    private fun fetchOneSecMailMessageDetail(
        login: String,
        domain: String,
        msgId: String,
        summaryObj: JSONObject
    ): EmailMessage {
        val detailUrl = "$ONE_SEC_MAIL_BASE/?action=readMessage&login=$login&domain=$domain&id=$msgId"
        val request = Request.Builder().url(detailUrl).get().build()

        val detailJson = runCatching {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    JSONObject(response.body?.string().orEmpty())
                } else {
                    summaryObj
                }
            }
        }.getOrElse { summaryObj }

        val fromAddress = detailJson.optString("from").ifBlank { summaryObj.optString("from") }
        val subject = detailJson.optString("subject").ifBlank { "(Sem assunto)" }
        val textBody = detailJson.optString("textBody")
            .ifBlank { detailJson.optString("body") }
        val htmlBody = detailJson.optString("htmlBody")
        val dateStr = detailJson.optString("date").ifBlank { summaryObj.optString("date") }
        val millis = parseOneSecDate(dateStr)

        return EmailMessage(
            id = msgId,
            fromAddress = fromAddress,
            fromName = fromAddress.substringBefore("@"),
            subject = subject,
            intro = textBody.take(120),
            textBody = textBody,
            htmlBody = htmlBody,
            receivedAtIso = dateStr,
            receivedAtMillis = millis,
            isRead = false
        )
    }

    private fun generateSecurePassword(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$"
        return buildString(16) {
            repeat(16) {
                append(chars[random.nextInt(chars.length)])
            }
        }
    }

    private fun parseIsoTimestamp(iso: String): Long {
        if (iso.isBlank()) return System.currentTimeMillis()
        return runCatching {
            Instant.parse(iso).toEpochMilli()
        }.getOrElse { System.currentTimeMillis() }
    }

    private fun parseOneSecDate(dateStr: String): Long {
        if (dateStr.isBlank()) return System.currentTimeMillis()
        return runCatching {
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            LocalDateTime.parse(dateStr, formatter).toInstant(ZoneOffset.UTC).toEpochMilli()
        }.getOrElse { System.currentTimeMillis() }
    }

    companion object {
        private const val PREFS_NAME = "temp_gm_vault_prefs"
        private const val KEY_ACCOUNT_JSON = "saved_account_json"
        private const val KEY_MESSAGES_JSON = "saved_messages_json"
        private const val KEY_SELECTED_SERVER = "selected_server_id"
        private const val KEY_VALIDITY_DAYS = "selected_validity_days"
        private const val KEY_AUTO_REFRESH = "auto_refresh_enabled"

        private const val MAIL_TM_BASE = "https://api.mail.tm"
        private const val ONE_SEC_MAIL_BASE = "https://www.1secmail.com/api/v1"
        const val MILLIS_PER_DAY = 86_400_000L
    }
}
