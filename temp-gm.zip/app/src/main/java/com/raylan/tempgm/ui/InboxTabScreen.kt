package com.raylan.tempgm.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.tempgm.InboxItemUi
import com.raylan.tempgm.R
import com.raylan.tempgm.TempGmUiState
import com.raylan.tempgm.ui.theme.CyberBackground
import com.raylan.tempgm.ui.theme.CyberBorder
import com.raylan.tempgm.ui.theme.CyberSurface
import com.raylan.tempgm.ui.theme.CyberSurfaceElevated
import com.raylan.tempgm.ui.theme.CyberTextPrimary
import com.raylan.tempgm.ui.theme.CyberTextSecondary
import com.raylan.tempgm.ui.theme.ElectricBlue
import com.raylan.tempgm.ui.theme.EmeraldGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InboxTabScreen(
    uiState: TempGmUiState,
    onRefreshClick: () -> Unit,
    onToggleAutoRefresh: (Boolean) -> Unit,
    onOpenMessage: (InboxItemUi) -> Unit,
    onCloseMessage: () -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val openLinkSafely: (String) -> Unit = { url ->
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            onNotify("Não foi possível abrir o link no navegador.")
        }
    }

    val copyCodeSafely: (String) -> Unit = { code ->
        runCatching {
            clipboardManager.setText(AnnotatedString(code))
            onNotify("Código $code copiado!")
        }.onFailure {
            onNotify("Falha ao copiar código.")
        }
    }

    if (uiState.selectedMessage != null) {
        MessageDetailScreen(
            item = uiState.selectedMessage,
            onBack = onCloseMessage,
            onCopyCode = copyCodeSafely,
            onOpenLink = openLinkSafely,
            modifier = modifier
        )
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            // Painel de controle da Caixa de Entrada
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = uiState.activeAccount?.address ?: "Sem caixa ativa",
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                color = if (uiState.activeAccount != null) EmeraldGreen else CyberTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${uiState.messages.size} mensagem(ns) salva(s) localmente",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextSecondary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Auto 8s",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (uiState.autoRefreshEnabled) EmeraldGreen else CyberTextSecondary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = uiState.autoRefreshEnabled,
                                onCheckedChange = onToggleAutoRefresh,
                                modifier = Modifier.testTag("auto_refresh_switch"),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = CyberBackground,
                                    checkedTrackColor = EmeraldGreen,
                                    uncheckedThumbColor = CyberTextSecondary,
                                    uncheckedTrackColor = CyberSurfaceElevated
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onRefreshClick,
                        enabled = !uiState.isRefreshing && uiState.activeAccount != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("refresh_messages_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricBlue,
                            contentColor = Color.White,
                            disabledContainerColor = CyberSurfaceElevated
                        )
                    ) {
                        if (uiState.isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "SINCRONIZANDO...",
                                style = MaterialTheme.typography.labelLarge
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Atualizar mensagens",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.btn_refresh_messages),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            if (uiState.messages.isEmpty()) {
                EmptyInboxState(
                    hasActiveAccount = uiState.activeAccount != null,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
                OfficialFooter()
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(
                        items = uiState.messages,
                        key = { it.message.id }
                    ) { item ->
                        InboxMessageCard(
                            item = item,
                            onClick = { onOpenMessage(item) },
                            onCopyCode = copyCodeSafely,
                            onOpenLink = openLinkSafely
                        )
                    }
                    item {
                        OfficialFooter()
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyInboxState(
    hasActiveAccount: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(ElectricBlue.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Inbox,
                contentDescription = "Caixa de entrada vazia",
                tint = ElectricBlue,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = if (hasActiveAccount) "Aguardando mensagens..." else "Nenhum e-mail ativo",
            style = MaterialTheme.typography.titleMedium,
            color = CyberTextPrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (hasActiveAccount) {
                "Assim que um serviço enviar um e-mail, o Extrator IA detectará códigos OTP e links de confirmação automaticamente."
            } else {
                "Volte para a aba Gerador e crie seu endereço temporário para começar a receber mensagens."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = CyberTextSecondary
        )
    }
}

@Composable
private fun InboxMessageCard(
    item: InboxItemUi,
    onClick: () -> Unit,
    onCopyCode: (String) -> Unit,
    onOpenLink: (String) -> Unit
) {
    val msg = item.message
    val extraction = item.extraction

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("message_card_${msg.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(
            width = 1.dp,
            color = if (extraction.verificationCode != null) {
                EmeraldGreen.copy(alpha = 0.55f)
            } else if (!msg.isRead) {
                ElectricBlue.copy(alpha = 0.55f)
            } else {
                CyberBorder
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (msg.isRead) Icons.Filled.MarkEmailRead else Icons.Filled.MarkEmailUnread,
                        contentDescription = if (msg.isRead) "Lido" else "Não lido",
                        tint = if (msg.isRead) CyberTextSecondary else ElectricBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = msg.fromName.ifBlank { msg.fromAddress.ifBlank { "Remetente" } },
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = formatTimestamp(msg.receivedAtMillis),
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = CyberTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = msg.subject,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = CyberTextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Chip de Resumo IA
            Surface(
                color = ElectricBlue.copy(alpha = 0.14f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Resumo IA",
                        tint = ElectricBlue,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = extraction.summary,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Card Verde Destacado para Código OTP Detectado
            if (extraction.verificationCode != null) {
                Spacer(modifier = Modifier.height(12.dp))
                AiOtpHighlightCard(
                    code = extraction.verificationCode,
                    onCopyCode = { onCopyCode(extraction.verificationCode) }
                )
            }

            // Botão Abrir Link de Confirmação
            if (extraction.confirmationLink != null) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onOpenLink(extraction.confirmationLink) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_link_button_${msg.id}"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ElectricBlue),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Link,
                        contentDescription = "Link de confirmação",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ABRIR LINK",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AiOtpHighlightCard(
    code: String,
    onCopyCode: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.14f)),
        border = BorderStroke(1.5.dp, EmeraldGreen)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Key,
                    contentDescription = "Código detectado pela IA",
                    tint = EmeraldGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "CÓDIGO DETECTADO PELA IA",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = EmeraldGreen,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onCopyCode,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("copy_otp_button_$code"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldGreen,
                    contentColor = Color(0xFF031E0E)
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = "Copiar código OTP",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "COPIAR CÓDIGO: $code",
                    style = MaterialTheme.typography.labelLarge,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
private fun MessageDetailScreen(
    item: InboxItemUi,
    onBack: () -> Unit,
    onCopyCode: (String) -> Unit,
    onOpenLink: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(enabled = true, onBack = onBack)

    val msg = item.message
    val extraction = item.extraction

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar para a caixa de entrada",
                        tint = CyberTextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = msg.subject,
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = msg.fromAddress.ifBlank { msg.fromName },
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            HorizontalDivider(color = CyberBorder)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface),
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = msg.subject,
                            style = MaterialTheme.typography.titleLarge,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "De: ${msg.fromName.ifBlank { "Remetente" }} <${msg.fromAddress}>",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            color = ElectricBlue
                        )
                        Text(
                            text = "Recebido em: ${formatTimestampFull(msg.receivedAtMillis)} • ${extraction.categoryLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = CyberTextSecondary
                        )
                    }
                }

                if (extraction.verificationCode != null) {
                    AiOtpHighlightCard(
                        code = extraction.verificationCode,
                        onCopyCode = { onCopyCode(extraction.verificationCode) }
                    )
                }

                if (extraction.confirmationLink != null) {
                    OutlinedButton(
                        onClick = { onOpenLink(extraction.confirmationLink) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, ElectricBlue),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Link,
                            contentDescription = "Abrir link de confirmação",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ABRIR LINK",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface),
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Text(
                        text = item.cleanBody,
                        style = MaterialTheme.typography.bodyLarge,
                        color = CyberTextPrimary,
                        modifier = Modifier.padding(16.dp)
                    )
                }

                OfficialFooter()
            }
        }
    }
}

private fun formatTimestamp(millis: Long): String {
    if (millis <= 0L) return "--:--"
    return runCatching {
        val formatter = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        formatter.format(Date(millis))
    }.getOrDefault("--:--")
}

private fun formatTimestampFull(millis: Long): String {
    if (millis <= 0L) return "--/--/----"
    return runCatching {
        val formatter = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        formatter.format(Date(millis))
    }.getOrDefault("--/--/----")
}
