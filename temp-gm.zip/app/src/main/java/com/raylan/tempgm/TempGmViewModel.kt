package com.raylan.tempgm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TempGmUiState(
    val securityStatus: SecurityStatus = SecurityStatus.Valid,
    val currentTab: Int = 0,
    val activeAccount: SavedAccount? = null,
    val selectedServer: MailServer = MailServer.MAIL_TM,
    val selectedValidityDays: Int = 10,
    val useCustomPrefix: Boolean = false,
    val customPrefixInput: String = "",
    val aiPreviewUsername: String = AiCodeExtractor.generateRealisticUsername(),
    val messages: List<InboxItemUi> = emptyList(),
    val selectedMessage: InboxItemUi? = null,
    val isGenerating: Boolean = false,
    val isRefreshing: Boolean = false,
    val autoRefreshEnabled: Boolean = true,
    val showReplaceConfirmDialog: Boolean = false,
    val showAboutDialog: Boolean = false,
    val remainingTimeText: String = "Nenhum e-mail ativo",
    val remainingProgress: Float = 0f,
    val isExpired: Boolean = false,
    val snackbarEvent: String? = null,
    val lastSyncTimestamp: Long? = null
)

class TempGmViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MailRepository(application)

    private val _uiState = MutableStateFlow(TempGmUiState())
    val uiState: StateFlow<TempGmUiState> = _uiState.asStateFlow()

    init {
        val initialSecurity = SecurityGuard.verifyIntegrity(application)
        val savedAccount = repository.loadSavedAccount()
        val savedMessages = repository.loadSavedMessages().toUiItems()
        val savedServer = repository.loadSelectedServer()
        val savedValidity = savedAccount?.validityDays ?: repository.loadPreferredValidityDays()
        val autoRefresh = repository.loadAutoRefreshEnabled()

        val (remainingText, progress, expired) = computeCountdown(savedAccount)

        // REGRA CRÍTICA: Nunca gera e-mail automaticamente nem troca de servidor ao abrir o app.
        _uiState.value = TempGmUiState(
            securityStatus = initialSecurity,
            activeAccount = savedAccount,
            selectedServer = savedAccount?.server ?: savedServer,
            selectedValidityDays = savedValidity,
            messages = savedMessages,
            autoRefreshEnabled = autoRefresh,
            remainingTimeText = remainingText,
            remainingProgress = progress,
            isExpired = expired
        )

        startContinuousSecurityAndTimerLoop()
        startAutoRefreshLoop()
    }

    fun recheckSecurity() {
        val status = SecurityGuard.verifyIntegrity(getApplication())
        _uiState.update { it.copy(securityStatus = status) }
    }

    private fun startContinuousSecurityAndTimerLoop() {
        viewModelScope.launch {
            var tickCount = 0
            while (isActive) {
                delay(4_000L)
                tickCount++
                val status = SecurityGuard.verifyIntegrity(getApplication())
                val account = _uiState.value.activeAccount
                val (remainingText, progress, expired) = computeCountdown(account)
                _uiState.update { state ->
                    state.copy(
                        securityStatus = status,
                        remainingTimeText = remainingText,
                        remainingProgress = progress,
                        isExpired = expired
                    )
                }
            }
        }
    }

    private fun startAutoRefreshLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(8_000L)
                val state = _uiState.value
                if (state.securityStatus is SecurityStatus.Valid &&
                    state.currentTab == 1 &&
                    state.autoRefreshEnabled &&
                    state.activeAccount != null &&
                    !state.isGenerating &&
                    !state.isRefreshing
                ) {
                    refreshMessages(silent = true)
                }
            }
        }
    }

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(currentTab = tabIndex) }
    }

    fun selectServer(server: MailServer) {
        repository.saveSelectedServer(server)
        _uiState.update { state ->
            val note = if (state.activeAccount != null && state.activeAccount.server != server) {
                "Servidor alterado para ${server.displayName}. Gere um novo e-mail quando desejar usar este servidor."
            } else {
                null
            }
            state.copy(
                selectedServer = server,
                snackbarEvent = note ?: state.snackbarEvent
            )
        }
    }

    fun selectValidityDays(days: Int) {
        val clamped = days.coerceIn(5, 20)
        val updatedAccount = repository.updateActiveAccountValidity(clamped)
        val (remainingText, progress, expired) = computeCountdown(updatedAccount ?: _uiState.value.activeAccount)
        _uiState.update { state ->
            state.copy(
                selectedValidityDays = clamped,
                activeAccount = updatedAccount ?: state.activeAccount,
                remainingTimeText = remainingText,
                remainingProgress = progress,
                isExpired = expired
            )
        }
    }

    fun setGenerationMode(useCustom: Boolean) {
        _uiState.update { it.copy(useCustomPrefix = useCustom) }
    }

    fun updateCustomPrefix(input: String) {
        _uiState.update { it.copy(customPrefixInput = input) }
    }

    fun regenerateAiPreview() {
        _uiState.update {
            it.copy(aiPreviewUsername = AiCodeExtractor.generateRealisticUsername())
        }
    }

    fun onGenerateButtonClicked() {
        val state = _uiState.value
        if (state.isGenerating) return

        if (state.useCustomPrefix && AiCodeExtractor.sanitizeCustomPrefix(state.customPrefixInput).length < 3) {
            _uiState.update {
                it.copy(snackbarEvent = "Digite um prefixo com pelo menos 3 caracteres válidos.")
            }
            return
        }

        if (state.activeAccount != null) {
            _uiState.update { it.copy(showReplaceConfirmDialog = true) }
        } else {
            executeGenerateNewEmail()
        }
    }

    fun dismissReplaceConfirmDialog() {
        _uiState.update { it.copy(showReplaceConfirmDialog = false) }
    }

    fun confirmReplaceAndGenerate() {
        _uiState.update { it.copy(showReplaceConfirmDialog = false) }
        executeGenerateNewEmail()
    }

    private fun executeGenerateNewEmail() {
        val state = _uiState.value
        if (state.isGenerating) return

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true) }

            val prefix = if (state.useCustomPrefix) {
                state.customPrefixInput
            } else {
                null
            }

            val result = repository.generateNewEmail(
                server = state.selectedServer,
                customPrefix = prefix,
                validityDays = state.selectedValidityDays
            )

            result.fold(
                onSuccess = { newAccount ->
                    val (remainingText, progress, expired) = computeCountdown(newAccount)
                    _uiState.update { current ->
                        current.copy(
                            isGenerating = false,
                            activeAccount = newAccount,
                            selectedServer = newAccount.server,
                            selectedValidityDays = newAccount.validityDays,
                            messages = emptyList(),
                            selectedMessage = null,
                            remainingTimeText = remainingText,
                            remainingProgress = progress,
                            isExpired = expired,
                            aiPreviewUsername = AiCodeExtractor.generateRealisticUsername(),
                            snackbarEvent = "E-mail gerado e salvo: ${newAccount.address}"
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { current ->
                        current.copy(
                            isGenerating = false,
                            snackbarEvent = error.message ?: "Erro de conexão ao gerar e-mail."
                        )
                    }
                }
            )
        }
    }

    fun refreshMessages(silent: Boolean = false) {
        val state = _uiState.value
        val account = state.activeAccount ?: run {
            if (!silent) {
                _uiState.update {
                    it.copy(snackbarEvent = "Gere um e-mail na aba Gerador antes de atualizar.")
                }
            }
            return
        }
        if (state.isRefreshing || state.isGenerating) return

        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            val result = repository.refreshMessages(account)

            result.fold(
                onSuccess = { updatedMessages ->
                    val latestSavedAccount = repository.loadSavedAccount() ?: account
                    val uiItems = updatedMessages.toUiItems()
                    val selectedId = _uiState.value.selectedMessage?.message?.id
                    val updatedSelected = selectedId?.let { id ->
                        uiItems.firstOrNull { it.message.id == id }
                    }
                    _uiState.update { current ->
                        current.copy(
                            isRefreshing = false,
                            activeAccount = latestSavedAccount,
                            messages = uiItems,
                            selectedMessage = updatedSelected,
                            lastSyncTimestamp = System.currentTimeMillis(),
                            snackbarEvent = if (!silent) {
                                if (uiItems.isEmpty()) "Caixa verificada: nenhuma mensagem nova."
                                else "${uiItems.size} mensagem(ns) sincronizada(s)."
                            } else current.snackbarEvent
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { current ->
                        current.copy(
                            isRefreshing = false,
                            snackbarEvent = if (!silent) {
                                error.message ?: "Falha ao atualizar caixa de entrada."
                            } else current.snackbarEvent
                        )
                    }
                }
            )
        }
    }

    fun toggleAutoRefresh(enabled: Boolean) {
        repository.saveAutoRefreshEnabled(enabled)
        _uiState.update {
            it.copy(
                autoRefreshEnabled = enabled,
                snackbarEvent = if (enabled) "Atualização automática (8s) ativada"
                else "Atualização automática pausada"
            )
        }
    }

    fun openMessage(item: InboxItemUi) {
        val updatedList = repository.markMessageAsRead(item.message.id).toUiItems()
        val openedItem = updatedList.firstOrNull { it.message.id == item.message.id } ?: item
        _uiState.update {
            it.copy(
                messages = updatedList,
                selectedMessage = openedItem
            )
        }
    }

    fun closeMessage() {
        _uiState.update { it.copy(selectedMessage = null) }
    }

    fun setShowAboutDialog(show: Boolean) {
        _uiState.update { it.copy(showAboutDialog = show) }
    }

    fun notifyMessage(message: String) {
        _uiState.update { it.copy(snackbarEvent = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarEvent = null) }
    }

    private fun List<EmailMessage>.toUiItems(): List<InboxItemUi> {
        return map { msg ->
            val extraction = AiCodeExtractor.analyze(msg)
            val cleanBody = AiCodeExtractor.cleanHtmlToReadableText(msg.htmlBody, msg.textBody)
                .ifBlank { msg.intro }
                .ifBlank { "(Mensagem sem conteúdo de texto)" }
            InboxItemUi(
                message = msg,
                extraction = extraction,
                cleanBody = cleanBody
            )
        }
    }

    private fun computeCountdown(account: SavedAccount?): Triple<String, Float, Boolean> {
        if (account == null) {
            return Triple("Nenhum e-mail ativo no momento", 0f, false)
        }
        val now = System.currentTimeMillis()
        val totalDuration = (account.expiresAtMillis - account.createdAtMillis).coerceAtLeast(1L)
        val remaining = account.expiresAtMillis - now

        if (remaining <= 0L) {
            return Triple("Expirado • Gere um novo quando desejar", 0f, true)
        }

        val totalMinutes = remaining / 60_000L
        val days = totalMinutes / (60L * 24L)
        val hours = (totalMinutes % (60L * 24L)) / 60L
        val minutes = totalMinutes % 60L

        val formatted = when {
            days > 0 -> "${days}d ${hours}h ${minutes}m restantes"
            hours > 0 -> "${hours}h ${minutes}m restantes"
            else -> "${minutes.coerceAtLeast(1)}m restantes"
        }

        val ratio = (remaining.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
        return Triple(formatted, ratio, false)
    }
}
