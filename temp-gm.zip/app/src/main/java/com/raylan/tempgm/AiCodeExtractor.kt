package com.raylan.tempgm

import androidx.core.text.HtmlCompat
import java.security.SecureRandom

object AiCodeExtractor {

    private val random = SecureRandom()

    private val firstNames = listOf(
        "lucas", "gabriel", "mateus", "rafael", "bruno", "pedro", "thiago", "felipe",
        "ana", "mariana", "juliana", "camila", "larissa", "beatriz", "fernanda", "amanda",
        "gustavo", "vinicius", "rodrigo", "leonardo", "caio", "henrique", "daniel", "marcelo"
    )

    private val lastNames = listOf(
        "silva", "santos", "oliveira", "souza", "pereira", "costa", "rodrigues", "almeida",
        "nascimento", "lima", "araujo", "fernandes", "carvalho", "gomes", "martins", "rocha",
        "ribeiro", "alves", "monteiro", "mendes", "barros", "freitas", "barbosa", "cardoso"
    )

    private val otpKeywords = listOf(
        "código", "codigo", "code", "otp", "pin", "token", "verificação", "verificacao",
        "verification", "confirmação", "confirmacao", "confirm", "passcode", "autenticação",
        "autenticacao", "auth", "2fa", "security", "segurança", "seguranca", "chave",
        "acesso", "access", "ativação", "ativacao", "activate", "validar", "validate"
    )

    private val labeledNumericRegex = Regex(
        """(?i)(?:c[oó]digo|code|otp|pin|token|passcode|verif[a-zçãõ]*|confirm[a-zçãõ]*|2fa|chave|acesso)[^a-zA-Z0-9]{0,24}([0-9]{4,8}|[0-9]{3}[-\s][0-9]{3})"""
    )

    private val labeledAlnumRegex = Regex(
        """(?i)(?:c[oó]digo|code|otp|token|chave|pin|voucher|key)[^a-zA-Z0-9]{0,20}([A-Z0-9]{2,4}-[A-Z0-9]{3,6}|(?=[A-Z0-9]{5,10}\b)(?=.*\d)(?=.*[A-Z])[A-Z0-9]{5,10})"""
    )

    private val standaloneSixToEightDigitRegex = Regex("""(?<!\d)([0-9]{6,8})(?!\d)""")
    private val standaloneFourToFiveDigitRegex = Regex("""(?<!\d)([0-9]{4,5})(?!\d)""")
    private val hyphenatedCodeRegex = Regex("""\b([A-Z]{1,4}-[0-9]{4,6}|[0-9]{3}-[0-9]{3})\b""")

    private val hrefRegex = Regex("""(?i)href\s*=\s*["'](https?://[^"'\s<>]+)["']""")
    private val rawUrlRegex = Regex("""https?://[^\s<>"'\)\]]+""")

    private val positiveLinkKeywords = listOf(
        "verify", "confirm", "activate", "activation", "validate", "verification",
        "token", "auth", "magic", "login", "signin", "signup", "reset", "code",
        "confirmar", "verificar", "ativar", "validar"
    )

    private val negativeLinkKeywords = listOf(
        "unsubscribe", "cancelar", "descadastrar", "optout", "privacy", "privacidade",
        "terms", "termos", "facebook.com", "instagram.com", "twitter.com", "x.com",
        "linkedin.com", "youtube.com", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".css", ".js"
    )

    fun generateRealisticUsername(): String {
        val first = firstNames[random.nextInt(firstNames.size)]
        val last = lastNames[random.nextInt(lastNames.size)]
        val number = 10 + random.nextInt(89)
        val separator = if (random.nextBoolean()) "." else ""
        return "$first$separator$last$number"
    }

    fun sanitizeCustomPrefix(rawPrefix: String): String {
        val beforeAt = rawPrefix.substringBefore("@").trim().lowercase()
        val cleaned = beforeAt
            .replace(" ", ".")
            .replace(Regex("[^a-z0-9._-]"), "")
            .trim('.', '-', '_')
        return cleaned
    }

    fun cleanHtmlToReadableText(html: String, fallbackText: String): String {
        return runCatching {
            val source = if (html.isNotBlank()) html else fallbackText
            if (source.isBlank()) return@runCatching ""
            if (html.isBlank()) {
                return@runCatching fallbackText.replace(Regex("\n{3,}"), "\n\n").trim()
            }

            val strippedHeadAndStyles = source
                .replace(Regex("(?is)<head[^>]*>.*?</head>"), " ")
                .replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
                .replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
                .replace(Regex("(?i)<br\\s*/?>"), "\n")
                .replace(Regex("(?i)</(p|div|tr|li|h[1-6]|section)>"), "\n")
                .replace(Regex("(?i)<li[^>]*>"), "\n• ")

            val spannedText = HtmlCompat.fromHtml(
                strippedHeadAndStyles,
                HtmlCompat.FROM_HTML_MODE_LEGACY
            ).toString()

            val normalized = spannedText
                .replace('\u00A0', ' ')
                .lines()
                .map { it.trimEnd() }
                .joinToString("\n")
                .replace(Regex("\n{3,}"), "\n\n")
                .trim()

            if (normalized.isNotBlank()) normalized else fallbackText.trim()
        }.getOrElse {
            fallbackText.ifBlank { html }.trim()
        }
    }

    fun analyze(message: EmailMessage): AiExtractionResult {
        return runCatching {
            val cleanBody = cleanHtmlToReadableText(message.htmlBody, message.textBody)
            val combinedText = buildString {
                append(message.subject)
                append('\n')
                append(cleanBody)
                if (cleanBody.isBlank() && message.intro.isNotBlank()) {
                    append('\n')
                    append(message.intro)
                }
            }

            val code = extractVerificationCode(combinedText)
            val link = extractConfirmationLink(message.htmlBody, combinedText)

            val senderLabel = message.fromName.ifBlank {
                message.fromAddress.substringBefore("@").ifBlank { "Remetente" }
            }

            val (category, summary) = buildSummary(
                subject = message.subject,
                body = combinedText,
                sender = senderLabel,
                code = code,
                link = link
            )

            AiExtractionResult(
                verificationCode = code,
                confirmationLink = link,
                summary = summary,
                categoryLabel = category
            )
        }.getOrElse {
            AiExtractionResult(
                verificationCode = null,
                confirmationLink = null,
                summary = "Mensagem recebida de ${message.fromAddress.ifBlank { "remetente desconhecido" }}",
                categoryLabel = "E-MAIL"
            )
        }
    }

    private fun extractVerificationCode(text: String): String? {
        if (text.isBlank()) return null

        // Remove URLs before scanning digits to avoid extracting IDs from tracking URLs
        val textWithoutUrls = text.replace(rawUrlRegex, " ")

        // 1. Labeled numeric code (highest confidence)
        labeledNumericRegex.find(textWithoutUrls)?.let { match ->
            val candidate = match.groupValues[1].replace(Regex("[\\s-]"), "")
            if (isValidNumericOtp(candidate, hasKeywordContext = true)) {
                return candidate
            }
        }

        // 2. Labeled alphanumeric code (e.g., GM-9482, A7K9P2)
        labeledAlnumRegex.find(textWithoutUrls)?.let { match ->
            val candidate = match.groupValues[1].trim()
            if (candidate.length in 5..12 && candidate.any { it.isDigit() }) {
                return candidate
            }
        }

        // 3. Hyphenated explicit verification code (e.g., 123-456 or AB-1234)
        hyphenatedCodeRegex.find(textWithoutUrls)?.let { match ->
            val candidate = match.groupValues[1]
            val lowerText = textWithoutUrls.lowercase()
            if (otpKeywords.any { lowerText.contains(it) }) {
                return candidate
            }
        }

        val lowerText = textWithoutUrls.lowercase()
        val hasOtpContext = otpKeywords.any { lowerText.contains(it) }

        // 4. Standalone 6-8 digit numeric OTP on lines or near text
        standaloneSixToEightDigitRegex.findAll(textWithoutUrls).forEach { match ->
            val candidate = match.groupValues[1]
            val lineContext = extractLineContext(textWithoutUrls, match.range.first)
            if (hasOtpContext || otpKeywords.any { lineContext.contains(it) }) {
                if (isValidNumericOtp(candidate, hasKeywordContext = true)) {
                    return candidate
                }
            }
        }

        // 5. Standalone 4-5 digit OTP ONLY when strong OTP keyword is on the same/nearby line
        if (hasOtpContext) {
            standaloneFourToFiveDigitRegex.findAll(textWithoutUrls).forEach { match ->
                val candidate = match.groupValues[1]
                val lineContext = extractLineContext(textWithoutUrls, match.range.first)
                if (otpKeywords.any { lineContext.contains(it) } &&
                    isValidNumericOtp(candidate, hasKeywordContext = false)
                ) {
                    return candidate
                }
            }
        }

        return null
    }

    private fun extractLineContext(text: String, index: Int): String {
        val start = (index - 80).coerceAtLeast(0)
        val end = (index + 80).coerceAtMost(text.length)
        return text.substring(start, end).lowercase()
    }

    private fun isValidNumericOtp(digits: String, hasKeywordContext: Boolean): Boolean {
        if (digits.length !in 4..8) return false
        val num = digits.toIntOrNull() ?: return false
        // Avoid common years unless strong explicit context
        if (!hasKeywordContext && digits.length == 4 && num in 1980..2035) return false
        // Avoid trivial repeated zeros like 0000
        if (digits.all { it == '0' }) return false
        return true
    }

    private fun extractConfirmationLink(html: String, plainText: String): String? {
        val candidates = linkedSetOf<String>()

        if (html.isNotBlank()) {
            hrefRegex.findAll(html).forEach { match ->
                val url = cleanTrailingPunctuation(match.groupValues[1])
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    candidates.add(url)
                }
            }
        }

        rawUrlRegex.findAll(plainText).forEach { match ->
            val url = cleanTrailingPunctuation(match.value)
            if (url.startsWith("http://") || url.startsWith("https://")) {
                candidates.add(url)
            }
        }

        if (candidates.isEmpty()) return null

        val scored = candidates.mapNotNull { url ->
            val lower = url.lowercase()
            if (negativeLinkKeywords.any { lower.contains(it) }) {
                return@mapNotNull null
            }
            var score = 0
            positiveLinkKeywords.forEach { keyword ->
                if (lower.contains(keyword)) score += 10
            }
            if (url.length > 35) score += 2
            url to score
        }

        if (scored.isEmpty()) return null
        val best = scored.maxByOrNull { it.second } ?: return null
        return if (best.second > 0 || scored.size == 1) best.first else scored.first().first
    }

    private fun cleanTrailingPunctuation(url: String): String {
        return url
            .replace("&amp;", "&")
            .trimEnd('.', ',', ';', ':', ')', ']', '>', '"', '\'')
    }

    private fun buildSummary(
        subject: String,
        body: String,
        sender: String,
        code: String?,
        link: String?
    ): Pair<String, String> {
        val lower = (subject + " " + body).lowercase()
        return when {
            code != null && link != null ->
                "OTP + LINK" to "Código de verificação ($code) e link detectados • $sender"
            code != null ->
                "CÓDIGO OTP" to "Código de verificação detectado • $sender"
            link != null ->
                "CONFIRMAÇÃO" to "Link de confirmação detectado • $sender"
            lower.contains("login") || lower.contains("acesso") || lower.contains("security") ||
                lower.contains("segurança") || lower.contains("alerta") ->
                "SEGURANÇA" to "Alerta de acesso/segurança • $sender"
            lower.contains("bem-vindo") || lower.contains("welcome") || lower.contains("conta") ->
                "BOAS-VINDAS" to "Notificação de conta • $sender"
            else ->
                "MENSAGEM" to "Mensagem de $sender"
        }
    }
}
