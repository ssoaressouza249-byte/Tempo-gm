package com.raylan.tempgm.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF0B0E14)
val CyberSurface = Color(0xFF141923)
val CyberSurfaceElevated = Color(0xFF1B2230)
val CyberBorder = Color(0xFF252E3F)
val ElectricBlue = Color(0xFF2979FF)
val ElectricBlueSoft = Color(0x262979FF)
val EmeraldGreen = Color(0xFF00E676)
val EmeraldGreenSoft = Color(0x2400E676)
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberWarning = Color(0xFFFFB300)
val CyberDanger = Color(0xFFFF3D57)
val SecurityTamperBg = Color(0xFF1A050A)
val SecurityTamperCard = Color(0xFF2A0912)
