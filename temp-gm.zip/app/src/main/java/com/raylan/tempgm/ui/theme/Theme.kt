package com.raylan.tempgm.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TempGmDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = ElectricBlueSoft,
    onPrimaryContainer = CyberTextPrimary,
    secondary = EmeraldGreen,
    onSecondary = Color(0xFF002110),
    secondaryContainer = EmeraldGreenSoft,
    onSecondaryContainer = EmeraldGreen,
    tertiary = CyberWarning,
    background = CyberBackground,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorder,
    error = CyberDanger,
    onError = Color.White
)

@Composable
fun TempGmTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TempGmDarkColorScheme,
        typography = TempGmTypography,
        content = content
    )
}
