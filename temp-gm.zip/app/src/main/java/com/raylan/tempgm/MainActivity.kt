package com.raylan.tempgm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raylan.tempgm.ui.AboutDialog
import com.raylan.tempgm.ui.GeneratorTabScreen
import com.raylan.tempgm.ui.InboxTabScreen
import com.raylan.tempgm.ui.SecurityBlockScreen
import com.raylan.tempgm.ui.theme.CyberBackground
import com.raylan.tempgm.ui.theme.CyberBorder
import com.raylan.tempgm.ui.theme.CyberSurface
import com.raylan.tempgm.ui.theme.CyberSurfaceElevated
import com.raylan.tempgm.ui.theme.CyberTextPrimary
import com.raylan.tempgm.ui.theme.CyberTextSecondary
import com.raylan.tempgm.ui.theme.ElectricBlue
import com.raylan.tempgm.ui.theme.EmeraldGreen
import com.raylan.tempgm.ui.theme.TempGmTheme

class MainActivity : ComponentActivity() {

    private var appViewModel: TempGmViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TempGmTheme {
                val vm: TempGmViewModel = viewModel()
                appViewModel = vm
                TempGmAppRoot(viewModel = vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        appViewModel?.recheckSecurity()
    }
}

@Composable
fun TempGmAppRoot(viewModel: TempGmViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarEvent) {
        val message = uiState.snackbarEvent
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbar()
        }
    }

    when (val security = uiState.securityStatus) {
        is SecurityStatus.Tampered -> {
            SecurityBlockScreen(technicalReason = security.technicalReason)
        }
        is SecurityStatus.Valid -> {
            val unreadCount = uiState.messages.count { !it.message.isRead }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = CyberBackground,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = {
                    SnackbarHost(hostState = snackbarHostState) { data ->
                        Snackbar(
                            snackbarData = data,
                            containerColor = CyberSurfaceElevated,
                            contentColor = CyberTextPrimary,
                            actionColor = EmeraldGreen,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                },
                topBar = {
                    TempGmTopBar(
                        onOpenAbout = { viewModel.setShowAboutDialog(true) }
                    )
                },
                bottomBar = {
                    TempGmBottomNav(
                        currentTab = uiState.currentTab,
                        unreadCount = unreadCount,
                        onSelectTab = viewModel::selectTab
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (uiState.currentTab == 0) {
                        GeneratorTabScreen(
                            uiState = uiState,
                            onCopyEmail = { address ->
                                viewModel.notifyMessage("E-mail copiado: $address")
                            },
                            onSelectValidity = viewModel::selectValidityDays,
                            onSetGenerationMode = viewModel::setGenerationMode,
                            onCustomPrefixChange = viewModel::updateCustomPrefix,
                            onRegenerateAiPreview = viewModel::regenerateAiPreview,
                            onSelectServer = viewModel::selectServer,
                            onGenerateClick = viewModel::onGenerateButtonClicked
                        )
                    } else {
                        InboxTabScreen(
                            uiState = uiState,
                            onRefreshClick = { viewModel.refreshMessages(silent = false) },
                            onToggleAutoRefresh = viewModel::toggleAutoRefresh,
                            onOpenMessage = viewModel::openMessage,
                            onCloseMessage = viewModel::closeMessage,
                            onNotify = viewModel::notifyMessage
                        )
                    }
                }
            }

            if (uiState.showReplaceConfirmDialog) {
                ReplaceEmailConfirmDialog(
                    currentEmail = uiState.activeAccount?.address.orEmpty(),
                    onConfirm = viewModel::confirmReplaceAndGenerate,
                    onDismiss = viewModel::dismissReplaceConfirmDialog
                )
            }

            if (uiState.showAboutDialog) {
                AboutDialog(onDismiss = { viewModel.setShowAboutDialog(false) })
            }
        }
    }
}

@Composable
private fun TempGmTopBar(onOpenAbout: () -> Unit) {
    Column(
        modifier = Modifier
            .background(CyberSurface)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(ElectricBlue.copy(alpha = 0.18f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = "Temp GM",
                        tint = ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = CyberTextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = EmeraldGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "CYBER VAULT",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = EmeraldGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Persistência Segura • Extrator IA",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberTextSecondary
                    )
                }
            }

            IconButton(
                onClick = onOpenAbout,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("about_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "Sobre o aplicativo",
                    tint = CyberTextSecondary
                )
            }
        }
        HorizontalDivider(color = CyberBorder)
    }
}

@Composable
private fun TempGmBottomNav(
    currentTab: Int,
    unreadCount: Int,
    onSelectTab: (Int) -> Unit
) {
    Column(modifier = Modifier.background(CyberSurface)) {
        HorizontalDivider(color = CyberBorder)
        NavigationBar(
            containerColor = CyberSurface,
            tonalElevation = 0.dp
        ) {
            NavigationBarItem(
                selected = currentTab == 0,
                onClick = { onSelectTab(0) },
                modifier = Modifier.testTag("tab_generator"),
                icon = {
                    Icon(
                        imageVector = if (currentTab == 0) Icons.Filled.Email else Icons.Outlined.Email,
                        contentDescription = stringResource(R.string.tab_generator)
                    )
                },
                label = {
                    Text(
                        text = stringResource(R.string.tab_generator),
                        fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ElectricBlue,
                    selectedTextColor = ElectricBlue,
                    indicatorColor = ElectricBlue.copy(alpha = 0.16f),
                    unselectedIconColor = CyberTextSecondary,
                    unselectedTextColor = CyberTextSecondary
                )
            )

            NavigationBarItem(
                selected = currentTab == 1,
                onClick = { onSelectTab(1) },
                modifier = Modifier.testTag("tab_inbox"),
                icon = {
                    BadgedBox(
                        badge = {
                            if (unreadCount > 0) {
                                Badge(
                                    containerColor = EmeraldGreen,
                                    contentColor = Color(0xFF042111)
                                ) {
                                    Text(
                                        text = if (unreadCount > 99) "99+" else unreadCount.toString(),
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (currentTab == 1) Icons.Filled.Inbox else Icons.Outlined.Inbox,
                            contentDescription = stringResource(R.string.tab_inbox)
                        )
                    }
                },
                label = {
                    Text(
                        text = stringResource(R.string.tab_inbox),
                        fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = EmeraldGreen,
                    selectedTextColor = EmeraldGreen,
                    indicatorColor = EmeraldGreen.copy(alpha = 0.16f),
                    unselectedIconColor = CyberTextSecondary,
                    unselectedTextColor = CyberTextSecondary
                )
            )
        }
    }
}

@Composable
private fun ReplaceEmailConfirmDialog(
    currentEmail: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        title = {
            Text(
                text = "Substituir E-mail Ativo?",
                style = MaterialTheme.typography.titleLarge,
                color = CyberTextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Você já possui uma caixa ativa salva:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary
                )
                Text(
                    text = currentEmail,
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = FontFamily.Monospace,
                    color = EmeraldGreen
                )
                Text(
                    text = "Gerar um novo endereço substituirá o e-mail atual e limpará a caixa local anterior. Deseja continuar?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextPrimary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_replace_email_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
            ) {
                Text("SUBSTITUIR E GERAR")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_replace_email_button")
            ) {
                Text("CANCELAR", color = CyberTextSecondary)
            }
        }
    )
}
