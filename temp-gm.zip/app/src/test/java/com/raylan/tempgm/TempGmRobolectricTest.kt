package com.raylan.tempgm

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TempGmRobolectricTest {

    @Test
    fun `verify app name and SecurityGuard passes on unmodified package`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Temp GM", context.getString(R.string.app_name))
        assertEquals("com.raylan.tempgm", context.packageName)
        val status = SecurityGuard.verifyIntegrity(context)
        assertTrue(status is SecurityStatus.Valid)
    }

    @Test
    fun `persistence loads null on fresh launch and preserves saved account and messages`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = MailRepository(context)
        assertNull(repo.loadSavedAccount())
        assertTrue(repo.loadSavedMessages().isEmpty())

        val account = SavedAccount(
            address = "lucas.silva94@mail.tm",
            password = "secret_password",
            token = "jwt_token_123",
            accountId = "acc_1",
            server = MailServer.MAIL_TM,
            createdAtMillis = 1_700_000_000_000L,
            validityDays = 15,
            expiresAtMillis = 1_700_000_000_000L + 15 * MailRepository.MILLIS_PER_DAY
        )
        repo.saveAccount(account)

        val message = EmailMessage(
            id = "msg_1",
            fromAddress = "noreply@service.com",
            fromName = "Service",
            subject = "Seu código de verificação",
            intro = "Use o código 482910",
            textBody = "Seu código de verificação é 482910. Confirme em https://service.com/verify?token=abc",
            htmlBody = "",
            receivedAtIso = "2026-01-01T10:00:00Z",
            receivedAtMillis = 1_700_000_100_000L,
            isRead = false
        )
        repo.saveMessages(listOf(message))

        val reloadedRepo = MailRepository(context)
        val loadedAccount = reloadedRepo.loadSavedAccount()
        val loadedMessages = reloadedRepo.loadSavedMessages()

        assertNotNull(loadedAccount)
        assertEquals("lucas.silva94@mail.tm", loadedAccount?.address)
        assertEquals(15, loadedAccount?.validityDays)
        assertEquals(1, loadedMessages.size)
        assertEquals("msg_1", loadedMessages.first().id)
    }
}
