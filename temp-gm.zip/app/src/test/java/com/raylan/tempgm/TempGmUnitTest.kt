package com.raylan.tempgm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TempGmUnitTest {

    @Test
    fun `AiCodeExtractor detects numeric OTP and confirmation link`() {
        val msg = EmailMessage(
            id = "1",
            fromAddress = "security@app.io",
            fromName = "App Security",
            subject = "Código de verificação: 928471",
            intro = "Use 928471 para confirmar",
            textBody = "Olá, seu código de verificação é 928471. Ou acesse: https://app.io/confirm?code=xyz123",
            htmlBody = "",
            receivedAtIso = "",
            receivedAtMillis = 1000L,
            isRead = false
        )

        val result = AiCodeExtractor.analyze(msg)
        assertEquals("928471", result.verificationCode)
        assertEquals("https://app.io/confirm?code=xyz123", result.confirmationLink)
        assertTrue(result.summary.contains("928471"))
    }

    @Test
    fun `AiCodeExtractor detects alphanumeric OTP and ignores unsubscribe links`() {
        val msg = EmailMessage(
            id = "2",
            fromAddress = "auth@example.com",
            fromName = "Example",
            subject = "Confirm your account",
            intro = "",
            textBody = "",
            htmlBody = """
                <html><body>
                <p>Use code <b>GM-4821</b> to verify.</p>
                <a href="https://example.com/verify-email?token=abc999">Confirmar E-mail</a>
                <a href="https://example.com/unsubscribe">Unsubscribe</a>
                </body></html>
            """.trimIndent(),
            receivedAtIso = "",
            receivedAtMillis = 2000L,
            isRead = false
        )

        val result = AiCodeExtractor.analyze(msg)
        assertEquals("GM-4821", result.verificationCode)
        assertEquals("https://example.com/verify-email?token=abc999", result.confirmationLink)
    }

    @Test
    fun `realistic username generator produces valid email prefix`() {
        val username = AiCodeExtractor.generateRealisticUsername()
        assertTrue(username.length >= 6)
        assertNotNull(username.matches(Regex("[a-z0-9.]+")))
        assertTrue(username.matches(Regex("[a-z0-9.]+")))
    }
}
